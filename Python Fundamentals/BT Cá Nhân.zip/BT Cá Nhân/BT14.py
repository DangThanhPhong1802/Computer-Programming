'''Viết câu lệnh xây dựng hàm Fibonacci(n) với n là số tự nhiên.
Hàm trả về 1 danh sách với các phần tử tương ứng là giá trị của dãy số Fibonacci có n giá trị'''
#xin vui lòng nhập số n vừa đủ , khi n>=35 thì KQ chạy chương trình load lâu!!!
while True :
    try :
        def f(n):
            if n == 0:
                return 0
            elif n == 1:
                return 1
            else:
                return f(n-1)+f(n-2)
        n=int(input("Nhập số tự nhiên n: "))
        giatri = [str(f(x)) for x in range(0, n)]
        print (",".join(giatri))
    except :
        continue