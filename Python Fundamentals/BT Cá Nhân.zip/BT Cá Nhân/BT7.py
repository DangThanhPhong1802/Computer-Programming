'''Viết chương trình cho phép nhập 1 chuỗi có (tối đa) 10 phần tử. Hiển thị chuỗi vừa nhập ra màn hình.
- 	In ra màn hình các giá trị sau: chiều dài của chuỗi, số lượng kí tự là dấu '  ' (khoảng trắng) trong chuỗi.
-	Chuyển chuỗi sang chữ HOA và xuất ra màn hình'''

while True :
    try :
        S = input('Mời bạn nhập 1 chuỗi ký tự : S = ')
        if len(S)<=10 :
            print('Chuỗi bạn vừa nhập là :', S)
            print('Độ dài chuỗi bạn vừa nhập là:', len(S))
            print('Số lượng khoảng trắng của chuỗi bạn vừa nhập là:', S.count(' '))
            print('Chuyển chuỗi bạn vừa nhập sang IN HOA toàn bộ:', S.upper())
        else :
            print('Mời bạn nhập lại chuỗi ký tự S !')
    except :
        continue