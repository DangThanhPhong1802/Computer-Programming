'''Viết chương trình với các yêu cầu sau.
-	Cho phép người sử dụng nhập vào ngày tháng năm sinh theo định dạng : ‘d:m:yyyy’
-	Tách và in riêng giá trị: ngày, tháng, năm'''
while True :
    A = input('Nhập ngày/tháng/năm theo định dạng d:m:yyyy: \n')
    try :
        d = A.find(':')
        m = A.find(':', d+2)
        yyyy = A.find(':', m+1)
        Ngay = A[:d]
        Thang = A[d+1:m]
        Nam = A[m+1:]
        x = int(Ngay)
        y = int(Thang)
        z = int(Nam)
        if 0<x<=31 and 0<y<=12 and z>=1000 :
            if Ngay.startswith('0') :
                Ngay = Ngay.replace('{}'.format(Ngay), '{}'.format(A[1:d]))
            if Thang.startswith('0') :
                Thang = Thang.replace(('{}'.format(Thang), '{}'.format(A[d+2:m])))
            print('Ngày: {}\nTháng: {}\nNăm: {}'.format(Ngay, Thang, Nam))
            break
        else :
            print('Mời bạn nhập lại dữ liệu hợp lý')
            continue
    except :
        print('Mời bạn nhập lại dữ liệu hợp lý')
        continue