#Viết chương trình nhập vào giá trị điện dung C, điện cảm L và tần số f. Tính và in ra tổng trở Z của mạch (công thức đã biết)
import math
while True :
    try :
        C = float(input('Nhập giá trị điện dung: C='))
        L = float(input('Nhập giá trị điện cảm: L='))
        f = float(input('Nhập giá trị tần số: f='))
        print('Giá trị tổng trở Z là : Z=', abs(2*math.pi*f*L - 1/(2*math.pi*f*C)))
    except :
        print('Mời bạn nhập lại giá trị hợp lý!')
        continue


