'''Viết chương trình tạo 1 danh sách 2 chiều (lưu dữ liệu dạng: 3 hàng 2 cột). Cho phép người sử dụng nhập các giá trị phần tử từ bàn phím.
a/ Hiển thị danh sách vừa nhập ra màn hình.
b/ Cho phép người sử dụng nhập vào giá trị cần tìm kiếm. Nếu tìm thấy có phần tử thỏa mãn yêu cầu tìm kiếm
   In ra màn hình vị trí (hàng, cột) của phần tử đó. Nếu không tìm thấy yêu cầu nhập lại giá trị tìm kiếm khác.'''

H = list()
row1 = list()
row2 = list()
row3 = list()

for i in range(2):
    x = input('Nhập giá trị cho hàng 1 cột {}: '.format(i+1))
    row1.append(x)
for i in range(2):
    x = input('Nhập giá trị cho hàng 2 cột {}: '.format(i+1))
    row2.append(x)
for i in range(2):
    x = input('Nhập giá trị cho hàng 3 cột {}: '.format(i+1))
    row3.append(x)

H.append(row1)
H.append(row2)
H.append(row3)


for n in H:
    print(n)


while True:
    c = False
    S = input('Nhập giá trị bạn cần tìm kiếm: ')
    for a in range(len(H)):
        for b in range(len(H[a])):
            if S == H[a][b]:
                print('-'*80)
                print('Số', S, 'bạn đang tìm nằm ở vị trí : hàng {} và cột {}'.format(a+1, b+1))
                c = True
                break
    if c == True:
        break
    else:
        print('Giá trị số', S, 'bạn đang tìm kiếm không hợp lệ! Vui lòng nhập lại !')