'''-Viết chương trình cho phép người dùng nhập một giá trị số nguyên, nếu nhập sai định dạng yêu cầu nhập lại giá trị.
- Tạo một List (danh sách) với các phần tử là số nguyên (giá trị tuân theo quy luật của dãy số Fibonacci) và số lượng phần tử bằng với giá trị vừa nhập.
- Hiển thị danh sách vừa nhập ra màn hình.
- In ra màn hình tất cả các giá trị là số nguyên tố có trong danh sách vừa nhập.'''

while True:
    try:
        def f(n):
            if n == 0:
                return 0
            elif n == 1:
                return 1
            else:
                return f(n - 1) + f(n - 2)

        def kiem_tra_1_so(b):
            for i in range(2, b):
                if (b % i) == 0:
                    return False
            return True

        n = int(input('\nMời bạn nhập số tự nhiên n: '))
        if n >= 0:
            a = [(f(x)) for x in range(0, n)]
            print('Dãy các số Fibonacci ứng với', n, 'giá trị là : ', a)
            print('Các số nguyên tố trong dãy Fibonacci bạn vừa tạo là: ')
            for i in range(3, len(a)):
                b = a[i]
                if kiem_tra_1_so(b):
                    print(b, end=' ')
            break
        else:
            print('Bạn đã nhập sai giá trị. Mời nhập lại !')
    except:
        print('Bạn đã nhập sai giá trị. Mời nhập lại !')
