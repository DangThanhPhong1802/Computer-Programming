#Nhập vào 1 số nguyên a => In ra dãy các số nguyên tố có trong đoạn [0,a]
while True :
    try :
        def kiem_tra_1_so(n):
            # x = 0 => không phải số nguyên tố
            # x = 1 => số nguyên tố
            x = 1
            if (n < 2):
                x = 0
                return x

            for p in range(2, n):
                if n % p == 0:
                    x = 0
                    break
            return x

        a = int(input("\nNhập vào 1 số nguyên a : "))
        for i in range(0,a+1):
            check = kiem_tra_1_so(i)
            if (check == 1):
                print(i, end=' ')
    except :
        continue
