#Nhập vào 1 chuỗi (tối đa 50 ký tự) => In ra màn hình chuỗi đó nhưng đã bị xóa khoảng trắng
while True :
    try :
        S = input('Mời bạn nhập 1 chuỗi ký tự : S = ')
        if len(S)<=50 :
            print('Kết quả mới của bạn là :', ''.join(S.split()))
        else :
            print('Mời bạn nhập lại chuỗi, chỉ được tối đa 50 ký tự !')
    except :
        continue