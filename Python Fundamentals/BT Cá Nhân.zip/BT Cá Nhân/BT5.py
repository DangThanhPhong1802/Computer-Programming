'''Viết chương trình tính tiền cước taxi với bảng giá như sau :
- 2  km đầu tiên  : 20.000 đ.
- 8  km tiếp theo : 7.000đ/km.
- 10 km tiếp theo : 5.000đ/km.
- Từ km thứ 21 	  : 3.000đ/km.
Dựa trên các thông số trên, viết chương trình có các chức năng sau :
- Cho phép người sử dụng nhập vào các số km đi được.
- Xuất ra màn hình tiền cước.'''

tong = 0
while True :
    try :
        S = float(input('Nhập vào số Km bạn đã đi được: S='))
        if S<=2 :
            tong = 20000
        elif 2<S<=10 :
            tong = 20000 + (S-2)*7000
        elif 10<S<=20 :
            tong = 20000 + 8*7000 + (S-10)*5000
        else :
            tong = 20000 + 8*7000 + 10*5000 + (S-20)*3000
        print('Tiền cước của bạn tổng cộng là: {:,}'.format(tong), 'đồng')
    except :
        continue