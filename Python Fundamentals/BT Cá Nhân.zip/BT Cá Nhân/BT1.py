#Nhập số nguyên có 3 chữ số => In ra chữ số hàng trăm - hàng chục - hàng đơn vị của số đó
while True :
    x = int(input('Nhập 1 số nguyên có 3 chữ số bất kỳ : '))
    try :
        if 0<=x<100 or x<=-1000 or x>=1000 or -100<x<=0 :
            print('Mời bạn nhập lại số nguyên có 3 chữ số !')
            continue
        elif 100<=x<1000 :
            print('Chữ số hàng trăm của', x, 'là:', (int(x/100)))
            print('Chữ số hàng chục của', x, 'là:', (x%100)//10)
            print('Chữ số hàng đơn vị của', x, 'là:', (x%10))
        else :    # -1000<x<=-100
            tram = int(x/100)
            x = abs(x)
            chuc = (x%100)//10
            dv = x%10
            print('Chữ số hàng trăm:{}\nChữ số hàng chục:{}\nChữ số hàng đơn vị:{}'.format(tram, chuc, dv))
    except :
        print('Mời bạn nhập lại số nguyên có 3 chữ số !')
        continue
