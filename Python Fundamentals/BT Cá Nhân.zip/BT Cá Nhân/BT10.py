'''Viết chương trình cho phép người dùng nhập lần lượt các giá trị (số nguyên) cho 1 List có 5 phần tử:
- Hiển thị danh sách vừa nhập ra màn hình.
- In ra màn hình các giá trị: Min, Max, giá trị trung bình các phần tử của danh sách.'''

A = []
while True :
    for j in range(1,6) :
        A.append(int(input('Mời bạn nhập số thứ ' + str(j) + ' : ')))
    print('-'*50)
    print('Danh sách A bạn vừa nhập là :', A)
    print('GTLN của A là', max(A))
    print('GTNN của A là:', min(A))
    print('GTTB của A là:', sum(A)/5)
    break