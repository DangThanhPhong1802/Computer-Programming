'''Viết câu lệnh xây dựng hàm Arange(A) với A là 1 danh sách (list).
-Hàm trả về 1 danh sách với các phần tử đã được sắp xếp theo thứ tự từ lớn đến bé và giá trị số chẵn đứng trước, số lẻ đứng sau.'''

n = int(input('Mời bạn nhập số phần tử tùy ý - vừa đủ : '))
A = []
for num_1 in range(1,n+1):
    A.append(int(input('Bạn hãy nhập giá trị cho phần tử thứ '+ str(num_1) + ' là : ')))
def Arange(A) :
    Even, Old = list(), list()
    for num_2 in A:
        if num_2 % 2 == 0:
            Even.append(num_2)
        else:
            Old.append(num_2)
        even_c = sorted(Even, reverse=True)
        odd_l = sorted(Old, reverse=True)
        B = even_c + odd_l
    return B
print('-'*80)
print('Các số sau khi được sắp xếp là : ', Arange(A))