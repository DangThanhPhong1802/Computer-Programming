def Check_Prime(n):
    for i in range(2, n):
        if (n % i) == 0:
            return False
    return True

n = int(input("Nhập số nguyên dương n = "))
if n >= 2:
    print("Các số nguyên tố không quá ", n, " là:")
    for i in range(2, n + 1):
        if Check_Prime(i):
            print (i,end=' ')
        i = i + 2
else:
    print("Mời nhập lại!")