'''-Viết chương trình cho phép người dùng nhập một giá trị số nguyên, nếu nhập sai định dạng yêu cầu nhập lại giá trị.
- Tạo một List (danh sách) với các phần tử là số nguyên (giá trị tuân theo quy luật của dãy số Fibonacci) và số lượng phần tử bằng với giá trị vừa nhập.
- Hiển thị danh sách vừa nhập ra màn hình.
- In ra màn hình tất cả các giá trị là số nguyên tố có trong danh sách vừa nhập.'''

import math
while True:
    try:
        d1 = 0
        d2 = 1
        x = int(input('Nhập giá trị số nguyên bất kì: '))
        M = [0,1]
        for i in range(2, x):
            d3 = d1 + d2
            M.append(d3)
            d1 = d2
            d2 = d3
        print('Danh sách giá trị nguyên tuân theo Fibonacci : ', M)
        L = list()
        for number in M:
            count = 0
            if number >= 2:
                for j in range(2, int(math.sqrt(number)) + 1):
                    if number % j == 0 :
                        count = count + 1
                if count == 0 :
                  L.append(number)
        if x >= 2:
            print('Các giá trị nguyên tố trong danh sách vừa tạo : ' + str(L).strip('[]'))
        break
    except:
        print('Bạn nhập sai giá trị. Vui lòng nhập lại !')
        continue