list = [['Nguyễn Bá Vũ Thạch','20146530',10],['Nguyễn Văn Ba','20145673',9.8],['Trần Văn Đại','20142340',9.5],['Đỗ Sĩ Tạ','20141220',5],['Đinh Công Lý','20121450',6]]
for n in list:
    print(n)
while True:
    check = False
    nhap = input('Nhập MSSV hoặc tên: ')
    for i in list:
        for j in i:
            if nhap == j:
                print(i[2], 'điểm')
                check = True
                break
    if check == True:
        break
    else:
        print('Giá trị bạn nhập không hợp lệ!')