'''Viết chương trình theo yêu cầu sau :
- Tạo sẵn 1 danh sách 2 chiều (danh sách lồng ghép) có 5 phần tử (mỗi phần tử có 3 giá trị: tương ứng – Họ tên, MSSV, Điểm).
- Hiển thị danh sách vừa nhập ra màn hình.
- Cho phép người dùng nhập vào MSSV (hoặc Họ tên). In điểm số tương ứng ra màn hình'''
list = [['Nguyễn A', '123456', 10], ['Nguyễn B', '654321', 9], ['Nguyễn C', '987654', 8], ['Nguyễn D', '456789', 7], ['Nguyễn E', '753951', 6]]
for x in list :
    print(x)
while True :
    c = False
    S = input('Vui lòng nhập Họ và Tên hoặc MSSV : ')
    for a in list :
        for b in a :
            if S==b :
                print('-'*80)
                print(S, ' : ', 'có điểm số là : ', a[2])
                c = True
                break
    if c == True :
        break
    else :
        print('Mời bạn nhập lại Họ và Tên hoặc MSSV chính xác ! Xin Cảm ơn !')
