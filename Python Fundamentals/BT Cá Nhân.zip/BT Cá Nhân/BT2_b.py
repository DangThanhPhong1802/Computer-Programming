'''Viết chương trình với các yêu cầu sau.
-	Cho phép người sử dụng nhập vào ngày tháng năm sinh theo định dạng : ‘d:m:yyyy’
-	Tách và in riêng giá trị: ngày, tháng, năm'''
while True :
    try :
        import datetime
        date_time_input = input('Mời bạn nhập vào ngày tháng năm theo định dạng d:m:yyyy : ')
        date_time_output = datetime.datetime.strptime(date_time_input, '%d:%m:%Y')
        print('Ngày : ', date_time_output.day)
        print('Tháng : ', date_time_output.month)
        print('Năm : ', date_time_output.year)
        break
    except :
        print('Mời bạn nhập lại đúng dữ liệu, đúng định dạng !')
        continue
