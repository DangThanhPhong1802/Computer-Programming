#Viết chương trình nhập vào giá trị chiều cao(m) và cân nặng (kg) theo định dạng số thực.
# Tính chỉ số BMI dựa theo thông tin vừa nhập và in kết quả BMI ra màn hình
# gầy: BMI<18.5; bình thường: BMI : 18.5-25; thừa cân: BMI: 25-30; béo phì: BMI > 30

while True :
    try :
        h = float(input('Nhập chiều cao (m) của bạn : h='))
        m = float(input('Nhập cân nặng (kg) của bạn : m='))
        BMI = m/(h*h)
        if BMI < 18.5 :
            print('Bạn đang bị gầy!!!')
        elif 18.5 <= BMI < 25 :
            print('Bạn đang bình thường!')
        elif 25 <= BMI <= 30 :
            print('Bạn đang bị thừa cân!!')
        else :
            print('Bạn đang bị béo phì!!!!')
    except :
        continue
    