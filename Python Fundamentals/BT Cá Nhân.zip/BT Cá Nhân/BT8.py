#Nhập định dạng 'họ và tên' => In ra toàn bộ dưới 2 định dạng : chữ cái đầu tiên viết hoa ; toàn bộ đều viết hoa
while True :
    try :
        str = input('Mời bạn nhập họ và tên : full name = ')
        print(str.title())
        print(str.upper())
    except :
        continue