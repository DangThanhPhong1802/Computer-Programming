from tkinter import *
window = Tk()
window.title("WELCOME")
window.geometry('400x400+200+300') #rộngxcao+x+y
B1=Button(window, text = "MENU", fg='green', bg='pink', relief='solid', font=("times new roman", 16,"bold"))
B1.pack(side='left', expand=1)




window.mainloop()