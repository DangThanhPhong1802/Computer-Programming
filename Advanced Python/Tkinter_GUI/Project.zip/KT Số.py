x=float(input('nhập vào 1 số bất kỳ : n= '))
if x<0 :
    print('số âm')
else :
    print('số dương')
